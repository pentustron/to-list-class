let tasks = [];
let completedTasks = [];

function addTask() {
  const taskInput = document.getElementById('taskInput');
  const task = taskInput.value.trim();

  if (task === '') {
    alert('Por favor, ingresa una tarea.');
    return;
  }

  if (tasks.includes(task) || completedTasks.includes(task)) {
    alert('Esta tarea ya está en la lista.');
    return;
  }

  tasks.push(task);
  renderTasks();
  taskInput.value = '';
}

function removeTask(index) {
  const task = tasks.splice(index, 1)[0];
  completedTasks.push(task);
  renderTasks();
}

function toggleTask(index) {
  const taskElement = document.getElementById(`task-${index}`);
  taskElement.classList.toggle('completed');
}

function removeAllCompleted() {
  completedTasks = [];
  renderTasks();
}

function renderTasks() {
  const taskList = document.getElementById('taskList');
  const completedTaskList = document.getElementById('completedTaskList');
  taskList.innerHTML = '';
  completedTaskList.innerHTML = '';

  tasks.forEach((task, index) => {
    const taskElement = createTaskElement(task, index);
    taskList.appendChild(taskElement);
  });

  completedTasks.forEach((task, index) => {
    const taskElement = createTaskElement(task, index, true);
    completedTaskList.appendChild(taskElement);
  });
}

function createTaskElement(task, index, completed = false) {
  const taskElement = document.createElement('div');
  taskElement.classList.add('task');
  taskElement.id = `task-${index}`;

  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.checked = completed;
  checkbox.addEventListener('change', () => toggleTask(index));

  const label = document.createElement('label');
  label.textContent = task;

  const removeButton = document.createElement('button');
  removeButton.textContent = 'Eliminar';
  removeButton.addEventListener('click', () => {
    if (completed) {
      completedTasks.splice(index, 1);
    } else {
      removeTask(index);
    }
    renderTasks();
  });

  taskElement.appendChild(checkbox);
  taskElement.appendChild(label);
  taskElement.appendChild(removeButton);

  return taskElement;
}

renderTasks(); // Llamada inicial para mostrar las tareas al cargar la página
